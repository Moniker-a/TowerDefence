#pragma once

class Event;

class EventHandlerBase
{
private:
public:
    virtual ~EventHandlerBase() { }
};
