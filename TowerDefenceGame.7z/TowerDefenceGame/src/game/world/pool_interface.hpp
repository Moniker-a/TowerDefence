#pragma once

//Empty class used to allow polymorphism with pools.
class PoolInterface
{  };
