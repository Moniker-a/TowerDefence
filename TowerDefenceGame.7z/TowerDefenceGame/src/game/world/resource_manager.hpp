#pragma once
#include "../resources/resource.hpp"
#include <unordered_map>

typedef boost::property_tree::ptree xml;

class ResourceManager
{
private:
    std::unordered_map<std::string, Resource> resourceMap;
public:
    //Using variadic templates this is basically an AnythingFactory. It will construct any type of object given the required parameters, then adds them to a single unordered_map.
    template <class ResourceType, class ... ConstructorArgTypes>
    void add_resource(std::string _tag, ConstructorArgTypes... constructorArgTypes)
    {
        resourceMap.emplace(std::make_pair(_tag, Resource(ResourceType(constructorArgTypes...))));
    }

    //Retrieved a named resource using a key / tag. Returns the resource as a const raw pointer (no ownership).
    template <class ResourceType>
    const ResourceType& get_resource(const std::string _key) const //Should return const raw const pointers.
    {
        return resourceMap.at(_key).unwrap<ResourceType>();
    }

    //Retrieved a named resource using a key / tag. Returns the resource raw pointer (no ownership).
    template <class ResourceType>
    ResourceType& get_nonconst_resource(const std::string _key) //Non-const version of get_resource... Required because of crazy allegro (e.g. see http://alleg.sourceforge.net/stabledocs/en/const.html#BITMAP%20objects )...
    {
        return resourceMap.at(_key).unwrap_nonconst<ResourceType>();
    }

    //Remove a specified resource.
    void erase_resource(const std::string _key) { resourceMap.erase(resourceMap.find(_key)); }

    //Clears all resources.
    void clear() { resourceMap.clear(); }

    ~ResourceManager()
    {
        std::cout << "destructing ResourceManager" << std::endl;
        clear();
    }
};
