#pragma once

#include <boost/property_tree/ptree.hpp>

//Defines an XML data type for configuration of game objects,
typedef boost::property_tree::ptree xml;
