#pragma once

//Base class from which all events are derived.
class Event
{
public:
private:
};
