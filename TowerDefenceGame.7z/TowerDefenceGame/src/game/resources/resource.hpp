#pragma once
#include <boost/property_tree/ptree.hpp>
#include <memory>

//Resource class providing a handle to generic game resources. Implements type erasure to support indefinite numbers of resource types.
class Resource
{
private:
    //Allows mixed storage in STL containers (not technically polymorphism except in destructor).
    class ResourceConcept
    {
    public:
        virtual ~ResourceConcept() {  }
    };

    //Templated model of ResourceConcept. Allows type erasure and storing of any type.
    template <class ResourceType>
    class ResourceModel : public ResourceConcept
    {
    private:
        ResourceType modelledResource;
    public:
        ResourceModel(const ResourceType &_resource) : modelledResource(_resource) {  }
        const ResourceType& get_resource() const { return modelledResource; } //Self-explanatory.
        ResourceType& get_nonconst_resource() { return modelledResource; } //Self-explanatory.
        virtual ~ResourceModel() {  }
    };

    //Unique pointer to the resource itself. Points to an object of type ResourceConcept allowing any specific instantiation of the templated ResourceModel to be stored.
    std::unique_ptr<ResourceConcept> resource;

public:
    //Constructor which initialises a resource with whichever ResourceModel is required.
    template <class ResourceType>
    Resource(const ResourceType& _resource) : resource(new ResourceModel<ResourceType>(_resource)) {  }// something to do with this??

    //Reverses type erasure to provide correctly typed const pointer to the raw resource.
    template <class ResourceType>
    const ResourceType& unwrap() const
    {
        return dynamic_cast<const ResourceModel<ResourceType>*>(resource.get())->get_resource(); //Faster type safety by manual checking against typeMap?
        //return dynamic_cast<const ResourceModel<ResourceType>*>(resource.get())->get_resource(); //Faster type safety by manual checking against typeMap?
    }

    //Reverses type erasure to provide correctly typed pointer to the raw resource.
    template <class ResourceType>
    ResourceType& unwrap_nonconst()
    {
        return dynamic_cast<ResourceModel<ResourceType>*>(resource.get())->get_nonconst_resource(); //Faster type safety by manual checking against typeMap?
    }

    //Implement non-copyable.
    //Resource(const Resource* _other) = delete;
    //Resource& operator= (const Resource&) = delete;
};
