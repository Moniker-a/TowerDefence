#include <allegro_image.h>
#include <iostream> //temp

//Wrapper for ALLEGRO_BITMAP* which ensures correct deletion with shared ownership.
class WrappedBitmap
{
private:
    class InnerWrapper
    {
    private:
        ALLEGRO_BITMAP* bitmap; //No const, see http://alleg.sourceforge.net/stabledocs/en/const.html#BITMAP%20objects
    public:
        InnerWrapper(const char* _filepath) : bitmap(al_load_bitmap(_filepath)) { std::cout << "InnerWrapper constructed: " << bitmap << std::endl; }
        ~InnerWrapper()
        {
            std::cout << "InnerWrapper destructed: " << bitmap << std::endl;
            al_destroy_bitmap(bitmap);
        }

        ALLEGRO_BITMAP* get() const { return bitmap; }
        //operator ALLEGRO_BITMAP* () const { return bitmap; } //Conversion from wrapper type to wrapped type.
    };

    std::shared_ptr<InnerWrapper> ptr;

public:
    WrappedBitmap(const char* _filepath) : ptr(std::make_shared<InnerWrapper>(_filepath)) { std::cout << "OuterWrapper constructed!" << std::endl; }
    WrappedBitmap(const WrappedBitmap& _other) : ptr(_other.ptr) { std::cout << "OuterWrapper constructed (copy constructor)!" << std::endl; }
    WrappedBitmap(const WrappedBitmap* _other) : ptr(_other->ptr) { std::cout << "OuterWrapper constructed (copy* constructor)!" << std::endl; }
    WrappedBitmap& operator= (const WrappedBitmap &_other) { std::cout << "OuterWrapper constructed (assignment operator)!" << std::endl; ptr = _other.ptr; return *this; }

    ~WrappedBitmap()
    {
        std::cout << "OuterWrapper destructed!" << std::endl;
    }
    operator ALLEGRO_BITMAP* () const { return ptr->get(); } //Conversion from wrapper type to wrapped type.
};

/*
    static void deleter(ALLEGRO_BITMAP** _toDelete)
    {
        std::cout << "CustomDeleter in action!" << std::endl;
        ALLEGRO_BITMAP* temp = *(_toDelete);
        al_destroy_bitmap(temp); //Seg fault here.
    }

public:
    WrappedBitmap(const char* _filepath)// : bitmap(al_load_bitmap(_filepath))
    {
        ALLEGRO_BITMAP* temp = al_load_bitmap(_filepath);
        bitmap = std::shared_ptr<ALLEGRO_BITMAP*>(&temp, deleter);
        std::cout << "WrappedBitmap created!" << std::endl;
    }

    operator ALLEGRO_BITMAP* () const { return *(bitmap.get()); } //Conversion from wrapper type to wrapped type.

    ~WrappedBitmap()
    {
        std::cout << "WrappedBitmap destroyed." << std::endl;
    }
};
*/


///Working not pointer.
//Wrapper for ALLEGRO_BITMAP which ensures correct deletion with shared ownership.
/*class WrappedBitmap
{
private:
    std::shared_ptr<ALLEGRO_BITMAP> bitmap; //No const, see http://alleg.sourceforge.net/stabledocs/en/const.html#BITMAP%20objects

    static void deleter(ALLEGRO_BITMAP* _toDelete)
    {
        std::cout << "WrappedBitmapCustomDeleter in action!" << std::endl;
        al_destroy_bitmap(_toDelete);
    }

public:
    WrappedBitmap(const char* _filepath) : bitmap(al_load_bitmap(_filepath))
    {
        std::cout << "WrappedBitmap created!" << std::endl;
    }

    operator ALLEGRO_BITMAP* () const { return bitmap.get(); } //Conversion from wrapper type to wrapped type.

    ~WrappedBitmap()
    {
        std::cout << "WrappedBitmap destroyed." << std::endl;
    }
};*/
